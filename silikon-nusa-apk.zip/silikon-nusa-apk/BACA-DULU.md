# Silikon Nusa: proyek APK

Proyek Android siap build. Game ada di app/src/main/assets/index.html (satu file, tanpa internet).

## Cara paling mudah: build otomatis di GitHub (tanpa Android Studio)
1. Buat repositori baru di github.com (boleh privat) lalu unggah SEMUA isi folder ini, termasuk folder .github.
2. Buka tab Actions, tunggu "Build APK" selesai (sekitar 3-5 menit).
3. Buka run yang selesai, unduh "SilikonNusa-apk" di bagian Artifacts, ekstrak zip-nya: isinya app-debug.apk.
4. Kirim APK ke HP, ketuk untuk memasang (izinkan "pasang dari sumber tidak dikenal").

## Alternatif: Android Studio
Open folder ini, tunggu sync, lalu Build > Build APK(s).

## Catatan
- Save game memakai penyimpanan lokal di HP; menghapus data aplikasi menghapus save.
- Simpan game terbaru: ganti file assets/index.html dengan versi baru.
